# README


* Ruby version = ruby 3.2.2 (2023-03-30 revision e51014f9c0) [x64-mingw-ucrt]

* C:\Ruby32-x64\cloudpro

* Configuration

* rails db:migrate


* rails generate model Contact name:string email:string phone:string


* rails generate controller Contacts


* unzipe file and put into correct file path 

* run above lines in cmd in the cd then run rails s and view on local host 3000

* ...
